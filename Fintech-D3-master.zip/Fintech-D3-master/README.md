# Fintech-D3
Day three work
